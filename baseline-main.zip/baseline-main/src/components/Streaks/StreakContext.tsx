import { createContext } from "react";

const StreakContext = createContext(0);

export default StreakContext;