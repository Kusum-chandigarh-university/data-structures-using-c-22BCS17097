const EndSpacer = () => {
    return <><div className="br"></div><div className="br"></div><div className="br"></div><div className="br"></div><div className="br"></div><div className="br"></div><div className="br"></div><div className="br"></div></>;
}

export default EndSpacer;