export enum Dialogs {
    NO_WRITING,
    SCALE_SHIFTED
}